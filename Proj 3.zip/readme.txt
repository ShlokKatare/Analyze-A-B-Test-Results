References:
StackOverflow.com